public void TraversingBackwards() 
{ 
    Node current = tail; 
    while (current != null) { 
        System.out.print(current.data + " "); 
        current = current.prev; 
    } 
} 

