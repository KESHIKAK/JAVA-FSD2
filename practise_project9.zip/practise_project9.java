import java.util.LinkedList;
import java.util.Queue;
public class EnQueueDequeue {
	public static void main(String[] args) {
		Queue<String> queue = new LinkedList<>();
		queue.add("Pen");
        queue.add("Pencil");
        queue.add("Eraser");
        queue.add("Sharpner");
        queue.add("Lead");
        queue.add("Sketch");
        
       System.out.println("Queue after adding: " + queue);
        String front = queue.remove();
        System.out.println("Removed element: " + front);
        System.out.println("Queue after removal: " + queue);
        
        
        
        
        
   
	}
}

