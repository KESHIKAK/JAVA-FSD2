import java.util.*;
public class RightRotate
{
    void rotate(int x[], int n, int r)
    {
        int i;
        System.out.println("Original Array is:  ");
        
        for(i=0;i<n;i++)
        {
            System.out.print(x[i] + " ");
        }

       
        for (int j=1;j<=r;j++)
        {
        
            int y = x[n-1];
            for(i=n-1;i>0;i--)
            {
             
                x[i] = x[i-1];
            }
           
         
            x[0] = y;

        }

        System.out.println(" ");
        System.out.println("Right Rotated Array are: ");

        for(i=0;i<n;i++)
        {
            System.out.print(x[i] + " ");
        }
    }
    
    public static void main(String[] args)
    {
        Scanner obj = new Scanner(System.in);
        System.out.println("Enter the number of elements in the array");
        int n = obj.nextInt();
        int A[] = new int[n];
        System.out.println("Enter the number of times the array needs to be rotated right");
        int r = obj.nextInt();
        System.out.println("Enter elements in array");
        for(int j=0;j<n;j++)
        {
            A[j] = obj.nextInt();
        }

        RightRotate array = new RightRotate();

        array.rotate(A, n, r);
    }
}
